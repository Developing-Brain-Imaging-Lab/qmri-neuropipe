# my_dmri_pipeline.py
from pathlib import Path
from qmri_neuropipe.core import (
    BasePipeline, BaseWorkflow, PipelineConfig
)
from qmri_neuropipe.lib.common.denoise import DenoisingStep

# Define a simple preprocessing workflow
class PreprocessingWorkflow(BaseWorkflow):
    """Preprocessing with denoising."""
    
    def _initialize_steps(self):
        self.steps = [
            DenoisingStep(
                self.config, 
                self.logger, 
                self.provenance
            )
        ]
    
    def run(self, dwi_file, output_dir):
        return self.execute_steps(dwi_file, output_dir)

# Define complete pipeline
class DMRIPipeline(BasePipeline):
    """Diffusion MRI Processing pipeline."""
    
    @property
    def name(self):
        return 'dmri-pipeline'
    
    @property
    def version(self):
        return '1.0.0'
    
    def _initialize_pipeline(self):
        self.preprocessing = PreprocessingWorkflow(
            self.config, self.logger, self.provenance
        )
    
    def process_subject(self, subject, session=None):
        # For this example, assume single DWI file
        dwi_file = Path(self.config.get('bids_dir')) / subject / 'dwi' / f'{subject}_dwi.nii.gz'
        output_dir = self._get_output_dir(subject, session)
        
        # Run preprocessing (includes denoising)
        denoised = self.preprocessing.run(dwi_file, output_dir)
        
        self.logger.info(f"Preprocessing complete: {denoised}")

# Run the pipeline
if __name__ == '__main__':
    # Create configuration
    config = PipelineConfig(
        bids_dir='/data/my_study',
        output_dir='/data/derivatives/simple-pipeline',
        n_cpus=8,
        skip_existing=True
    )
    
    # Create and run pipeline
    pipeline = DMRIPipeline(config)
    pipeline.run()  # Processes all subjects automatically!
