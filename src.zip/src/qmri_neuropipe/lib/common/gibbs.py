"""
Denoising module for neuroimaging data.

This module provides denoising methods that work across multiple modalities:
- dMRI: MP-PCA (Marchenko-Pastur PCA)
- fMRI: Non-local means, wavelets
- Anatomical: Non-local means, anisotropic diffusion

All denoising steps inherit from BaseProcessingStep for automatic
validation, logging, and provenance tracking.

Classes:
    DenoisingStep: Main denoising class with multiple methods
    MPPCADenoisingStep: Specialized MP-PCA for dMRI
    NLMeansDenoisingStep: Non-local means for any modality
    WaveletDenoisingStep: Wavelet-based denoising
"""

from pathlib import Path
from typing import Optional, Literal, Tuple, Dict, Any
import numpy as np
import nibabel as nib
import logging

from ...core import BaseProcessingStep, ValidationError, ProcessingError

# Try to import optional dependencies
try:
    from dipy.denoise.localpca import mppca
    from dipy.denoise.pca_noise_estimate import pca_noise_estimate
    DIPY_AVAILABLE = True
except ImportError:
    DIPY_AVAILABLE = False

try:
    from dipy.denoise.nlmeans import nlmeans
    from dipy.denoise.noise_estimate import estimate_sigma
    NLMEANS_AVAILABLE = True
except ImportError:
    NLMEANS_AVAILABLE = False


class DenoisingStep(BaseProcessingStep):
    """
    General denoising step that works for multiple modalities.
    
    Supports multiple denoising methods:
    - 'mppca': Marchenko-Pastur PCA (best for dMRI)
    - 'nlmeans': Non-local means (works for all modalities)
    - 'wavelets': Wavelet-based denoising (experimental)
    - 'gaussian': Simple Gaussian smoothing (fallback)
    
    Used by:
    - dMRI: Typically uses MP-PCA
    - fMRI: Typically uses non-local means or wavelets
    - Anatomical: Typically uses non-local means
    
    Attributes:
        method: Denoising method to use
        patch_radius: Size of patch for local methods
        block_radius: Size of block for non-local methods
        
    Example:
        >>> # For dMRI
        >>> denoising = DenoisingStep(config, method='mppca')
        >>> denoised = denoising(dwi_file, output_dir)
        >>> 
        >>> # For fMRI
        >>> denoising = DenoisingStep(config, method='nlmeans')
        >>> denoised = denoising(bold_file, output_dir)
    """
    
    def __init__(
        self,
        config,
        method: Literal['mppca', 'nlmeans', 'wavelets', 'gaussian'] = 'mppca',
        patch_radius: int = 2,
        block_radius: int = 5,
        logger: Optional[logging.Logger] = None,
        provenance = None
    ):
        """
        Initialize denoising step.
        
        Args:
            config: Pipeline configuration
            method: Denoising method to use
            patch_radius: Patch size for local methods (default: 2)
            block_radius: Block size for non-local methods (default: 5)
            logger: Optional logger instance
            provenance: Optional provenance tracker
        
        Raises:
            ProcessingError: If required dependencies are missing
        """
        super().__init__(config, logger, provenance)
        
        self.method = method
        self.patch_radius = patch_radius
        self.block_radius = block_radius
        
        # Check dependencies
        self._check_dependencies()
        
        self.logger.info(f"Initialized denoising with method: {method}")
    
    def _check_dependencies(self) -> None:
        """Check that required dependencies are available."""
        if self.method == 'mppca' and not DIPY_AVAILABLE:
            raise ProcessingError(
                "DIPY not available. Install with: pip install dipy"
            )
        
        if self.method == 'nlmeans' and not NLMEANS_AVAILABLE:
            raise ProcessingError(
                "DIPY nlmeans not available. Install with: pip install dipy"
            )
    
    def validate_inputs(
        self,
        input_image: Path,
        output_dir: Path,
        **kwargs
    ) -> None:
        """
        Validate denoising inputs.
        
        Args:
            input_image: Path to input NIfTI file
            output_dir: Output directory
            **kwargs: Additional arguments
        
        Raises:
            ValidationError: If inputs are invalid
        """
        # Check input file exists
        if not input_image.exists():
            raise ValidationError(f"Input image not found: {input_image}")
        
        # Check it's a valid NIfTI file
        try:
            img = nib.load(str(input_image))
            
            # Check dimensions
            if len(img.shape) < 3:
                raise ValidationError(
                    f"Input must be at least 3D, got shape {img.shape}"
                )
            
            # For MP-PCA, need 4D data
            if self.method == 'mppca' and len(img.shape) != 4:
                raise ValidationError(
                    f"MP-PCA requires 4D data, got shape {img.shape}"
                )
            
        except Exception as e:
            raise ValidationError(f"Invalid NIfTI file: {e}")
        
        self.logger.debug(f"Input validation passed for {input_image.name}")
    
    def run(
        self,
        input_image: Path,
        output_dir: Path,
        mask: Optional[Path] = None,
        **kwargs
    ) -> Path:
        """
        Run denoising on input image.
        
        Args:
            input_image: Path to input NIfTI file
            output_dir: Output directory for denoised image
            mask: Optional brain mask (speeds up processing)
            **kwargs: Method-specific parameters
        
        Returns:
            Path to denoised image
        
        Raises:
            ProcessingError: If denoising fails
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Load data
        self.logger.info(f"Loading image: {input_image.name}")
        img = nib.load(str(input_image))
        data = img.get_fdata()
        
        # Load mask if provided
        mask_data = None
        if mask and mask.exists():
            self.logger.info(f"Using mask: {mask.name}")
            mask_img = nib.load(str(mask))
            mask_data = mask_img.get_fdata().astype(bool)
        
        # Run denoising based on method
        self.logger.info(f"Running {self.method} denoising...")
        
        try:
            if self.method == 'mppca':
                denoised, sigma = self._run_mppca(data, mask_data, **kwargs)
            elif self.method == 'nlmeans':
                denoised = self._run_nlmeans(data, mask_data, **kwargs)
            elif self.method == 'wavelets':
                denoised = self._run_wavelets(data, mask_data, **kwargs)
            elif self.method == 'gaussian':
                denoised = self._run_gaussian(data, mask_data, **kwargs)
            else:
                raise ValueError(f"Unknown denoising method: {self.method}")
        
        except Exception as e:
            raise ProcessingError(
                f"Denoising failed with method {self.method}",
                step_name="denoising",
                details=str(e)
            )
        
        # Save denoised image
        output_file = output_dir / f"{input_image.stem}_denoised.nii.gz"
        denoised_img = nib.Nifti1Image(denoised, img.affine, img.header)
        nib.save(denoised_img, str(output_file))
        
        self.logger.info(f"Denoised image saved to: {output_file}")
        
        # Also save noise map if MP-PCA
        if self.method == 'mppca' and sigma is not None:
            sigma_file = output_dir / f"{input_image.stem}_sigma.nii.gz"
            sigma_img = nib.Nifti1Image(sigma, img.affine, img.header)
            nib.save(sigma_img, str(sigma_file))
            self.logger.debug(f"Noise map saved to: {sigma_file}")
        
        return output_file
    
    def validate_outputs(self, result: Path) -> None:
        """
        Validate denoising outputs.
        
        Args:
            result: Path to output file
        
        Raises:
            ProcessingError: If output validation fails
        """
        if not result.exists():
            raise ProcessingError(f"Denoised image not created: {result}")
        
        # Check output is valid and has reasonable values
        try:
            img = nib.load(str(result))
            data = img.get_fdata()
            
            # Check for NaN or Inf
            if np.any(np.isnan(data)):
                raise ProcessingError("Denoised image contains NaN values")
            if np.any(np.isinf(data)):
                raise ProcessingError("Denoised image contains Inf values")
            
            # Check data range is reasonable (non-negative for MRI)
            if np.any(data < 0):
                self.logger.warning("Denoised image contains negative values")
            
            self.logger.debug(
                f"Output validation passed. "
                f"Data range: [{data.min():.2f}, {data.max():.2f}]"
            )
            
        except Exception as e:
            raise ProcessingError(f"Output validation failed: {e}")
    
    def _run_mppca(
        self,
        data: np.ndarray,
        mask: Optional[np.ndarray] = None,
        **kwargs
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Run Marchenko-Pastur PCA denoising.
        
        Best for dMRI data with multiple volumes.
        
        Args:
            data: 4D array (x, y, z, volumes)
            mask: Optional 3D binary mask
            **kwargs: Additional parameters
        
        Returns:
            Tuple of (denoised_data, sigma_map)
        """
        self.logger.debug(
            f"Running MP-PCA with patch_radius={self.patch_radius}"
        )
        
        # Get patch radius from kwargs or use default
        patch_radius = kwargs.get('patch_radius', self.patch_radius)
        
        # Run MP-PCA
        denoised_arr, sigma = mppca(
            data,
            mask=mask,
            patch_radius=patch_radius,
            return_sigma=True
        )
        
        # Calculate noise reduction
        if mask is not None:
            original_std = np.std(data[mask])
            denoised_std = np.std(denoised_arr[mask])
        else:
            original_std = np.std(data)
            denoised_std = np.std(denoised_arr)
        
        noise_reduction = (1 - denoised_std / original_std) * 100
        self.logger.info(
            f"MP-PCA reduced noise by {noise_reduction:.1f}% "
            f"(std: {original_std:.2f} → {denoised_std:.2f})"
        )
        
        return denoised_arr, sigma
    
    def _run_nlmeans(
        self,
        data: np.ndarray,
        mask: Optional[np.ndarray] = None,
        **kwargs
    ) -> np.ndarray:
        """
        Run non-local means denoising.
        
        Works for any modality (dMRI, fMRI, anatomical).
        
        Args:
            data: 3D or 4D array
            mask: Optional binary mask
            **kwargs: Additional parameters
        
        Returns:
            Denoised data
        """
        self.logger.debug(
            f"Running non-local means with "
            f"patch_radius={self.patch_radius}, "
            f"block_radius={self.block_radius}"
        )
        
        # Estimate noise level
        sigma = estimate_sigma(data, N=0)
        self.logger.debug(f"Estimated noise level (sigma): {sigma:.4f}")
        
        # Get parameters
        patch_radius = kwargs.get('patch_radius', self.patch_radius)
        block_radius = kwargs.get('block_radius', self.block_radius)
        
        # Run NLMeans
        if len(data.shape) == 4:
            # Process each volume separately for 4D data
            denoised_arr = np.zeros_like(data)
            for vol in range(data.shape[3]):
                denoised_arr[..., vol] = nlmeans(
                    data[..., vol],
                    sigma=sigma,
                    mask=mask,
                    patch_radius=patch_radius,
                    block_radius=block_radius
                )
            self.logger.debug(f"Processed {data.shape[3]} volumes")
        else:
            # 3D data
            denoised_arr = nlmeans(
                data,
                sigma=sigma,
                mask=mask,
                patch_radius=patch_radius,
                block_radius=block_radius
            )
        
        # Calculate noise reduction
        if mask is not None:
            original_std = np.std(data[mask])
            denoised_std = np.std(denoised_arr[mask])
        else:
            original_std = np.std(data)
            denoised_std = np.std(denoised_arr)
        
        noise_reduction = (1 - denoised_std / original_std) * 100
        self.logger.info(
            f"NLMeans reduced noise by {noise_reduction:.1f}%"
        )
        
        return denoised_arr
    
    def _run_wavelets(
        self,
        data: np.ndarray,
        mask: Optional[np.ndarray] = None,
        **kwargs
    ) -> np.ndarray:
        """
        Run wavelet-based denoising.
        
        Uses soft thresholding in wavelet domain.
        
        Args:
            data: 3D or 4D array
            mask: Optional binary mask
            **kwargs: Additional parameters
        
        Returns:
            Denoised data
        """
        try:
            import pywt
        except ImportError:
            raise ProcessingError(
                "PyWavelets not available. Install with: pip install PyWavelets"
            )
        
        self.logger.debug("Running wavelet denoising")
        
        # Get wavelet type and threshold
        wavelet = kwargs.get('wavelet', 'db4')
        threshold_method = kwargs.get('threshold_method', 'BayesShrink')
        
        def denoise_3d(volume):
            """Denoise a 3D volume using wavelets."""
            # Perform 3D wavelet decomposition
            coeffs = pywt.wavedecn(volume, wavelet, level=3)
            
            # Threshold detail coefficients
            coeffs_thresh = [coeffs[0]]  # Keep approximation
            for detail in coeffs[1:]:
                detail_thresh = {}
                for key, value in detail.items():
                    if threshold_method == 'BayesShrink':
                        sigma = np.median(np.abs(value)) / 0.6745
                        thresh = sigma * np.sqrt(2 * np.log(value.size))
                    else:
                        thresh = kwargs.get('threshold', 1.0)
                    
                    detail_thresh[key] = pywt.threshold(
                        value, thresh, mode='soft'
                    )
                coeffs_thresh.append(detail_thresh)
            
            # Reconstruct
            denoised = pywt.waverecn(coeffs_thresh, wavelet)
            
            return denoised
        
        # Process data
        if len(data.shape) == 4:
            denoised_arr = np.zeros_like(data)
            for vol in range(data.shape[3]):
                denoised_arr[..., vol] = denoise_3d(data[..., vol])
        else:
            denoised_arr = denoise_3d(data)
        
        return denoised_arr
    
    def _run_gaussian(
        self,
        data: np.ndarray,
        mask: Optional[np.ndarray] = None,
        **kwargs
    ) -> np.ndarray:
        """
        Run simple Gaussian smoothing.
        
        Fallback method that doesn't require special dependencies.
        
        Args:
            data: 3D or 4D array
            mask: Optional binary mask
            **kwargs: Additional parameters
        
        Returns:
            Smoothed data
        """
        from scipy.ndimage import gaussian_filter
        
        sigma = kwargs.get('sigma', 1.0)
        self.logger.debug(f"Running Gaussian smoothing with sigma={sigma}")
        
        if len(data.shape) == 4:
            # Don't smooth in time dimension
            smoothed = np.zeros_like(data)
            for vol in range(data.shape[3]):
                smoothed[..., vol] = gaussian_filter(data[..., vol], sigma=sigma)
        else:
            smoothed = gaussian_filter(data, sigma=sigma)
        
        return smoothed
    
    def _log_provenance(
        self,
        input_image: Path,
        output_dir: Path,
        result: Path,
        mask: Optional[Path] = None,
        **kwargs
    ) -> None:
        """
        Log detailed provenance for denoising.
        
        Overrides base class method to add denoising-specific info.
        """
        if self.provenance:
            inputs = {'image': str(input_image)}
            if mask:
                inputs['mask'] = str(mask)
            
            parameters = {
                'method': self.method,
                'patch_radius': self.patch_radius,
                'block_radius': self.block_radius,
            }
            parameters.update(kwargs)
            
            self.provenance.log_step(
                step_name='denoising',
                inputs=inputs,
                outputs={'denoised_image': str(result)},
                parameters=parameters,
                duration=(self.end_time - self.start_time).total_seconds()
                if self.end_time and self.start_time else None
            )


# class MPPCADenoisingStep(DenoisingStep):
#     """
#     Specialized MP-PCA denoising for dMRI.
    
#     This is a convenience class that pre-configures DenoisingStep
#     for MP-PCA method with dMRI-specific defaults.
    
#     Example:
#         >>> denoising = MPPCADenoisingStep(config)
#         >>> denoised = denoising(dwi_file, output_dir)
#     """
    
#     def __init__(self, config, patch_radius: int = 2, **kwargs):
#         """
#         Initialize MP-PCA denoising.
        
#         Args:
#             config: Pipeline configuration
#             patch_radius: Patch size (default: 2)
#             **kwargs: Additional arguments for DenoisingStep
#         """
#         super().__init__(
#             config,
#             method='mppca',
#             patch_radius=patch_radius,
#             **kwargs
#         )


# class NLMeansDenoisingStep(DenoisingStep):
#     """
#     Specialized non-local means denoising.
    
#     Works for any modality. This is a convenience class that
#     pre-configures DenoisingStep for NLMeans method.
    
#     Example:
#         >>> denoising = NLMeansDenoisingStep(config)
#         >>> denoised = denoising(image_file, output_dir)
#     """
    
#     def __init__(
#         self,
#         config,
#         patch_radius: int = 1,
#         block_radius: int = 5,
#         **kwargs
#     ):
#         """
#         Initialize NLMeans denoising.
        
#         Args:
#             config: Pipeline configuration
#             patch_radius: Patch size (default: 1)
#             block_radius: Block size (default: 5)
#             **kwargs: Additional arguments for DenoisingStep
#         """
#         super().__init__(
#             config,
#             method='nlmeans',
#             patch_radius=patch_radius,
#             block_radius=block_radius,
#             **kwargs
#         )


# Convenience function for quick denoising
def denoise_image(
    input_image: Path,
    output_file: Path,
    method: str = 'mppca',
    mask: Optional[Path] = None,
    **kwargs
) -> Path:
    """
    Convenience function for quick denoising without full pipeline setup.
    
    Args:
        input_image: Input image path
        output_file: Output image path
        method: Denoising method ('mppca', 'nlmeans', etc.)
        mask: Optional mask path
        **kwargs: Method-specific parameters
    
    Returns:
        Path to denoised image
    
    Example:
        >>> from qmri_neuropipe.processing.common.denoising import denoise_image
        >>> 
        >>> denoised = denoise_image(
        ...     input_image=Path('dwi.nii.gz'),
        ...     output_file=Path('denoised.nii.gz'),
        ...     method='mppca'
        ... )
    """
    # Create minimal config
    from qmri_neuropipe.core import PipelineConfig
    
    config = PipelineConfig(
        bids_dir=Path('/tmp'),  # Dummy value
        output_dir=output_file.parent
    )
    
    # Run denoising
    denoiser = DenoisingStep(config, method=method)
    
    # Temporarily disable validation for standalone use
    denoiser.validate_inputs = lambda *args, **kwargs: None
    
    result = denoiser.run(
        input_image,
        output_file.parent,
        mask=mask,
        **kwargs
    )
    
    return result


# Module version and metadata
__version__ = '2.0.0'
__all__ = [
    'DenoisingStep',
    'denoise_image'
]

#    'MPPCADenoisingStep',
#    'NLMeansDenoisingStep',