"""
Denoising module for neuroimaging data.

This module provides denoising methods that work across multiple modalities:
- dMRI: MP-PCA (Marchenko-Pastur PCA)
- fMRI: Non-local means, wavelets
- Anatomical: Non-local means, anisotropic diffusion

All denoising steps inherit from BaseProcessingStep for automatic
validation, logging, and provenance tracking.

Classes:
    DenoisingStep: Main denoising class with multiple methods
    denoise_image: Convenience function for quick denoising without full pipeline setup.
"""

from pathlib import Path
from typing import Optional, Literal, Tuple
import numpy as np
import nibabel as nib
import logging

from ...core import BaseProcessingStep, ValidationError, ProcessingError
from ...interfaces import dipy, ants, mrtrix

class DenoisingStep(BaseProcessingStep):
    """
    General denoising step that works for multiple modalities.
    
    Supports multiple denoising methods:
    - 'mrtrix': MRtrix3 dwidenoise
    - 'ants': ANTs DenoiseImage
    - 'mppca': Marchenko-Pastur PCA (best for dMRI)
    - 'nlmeans': Non-local means (works for all modalities)
    - 'wavelets': Wavelet-based denoising (experimental)
    - 'gaussian': Simple Gaussian smoothing (fallback)
    
    Used by:
    - dMRI: Typically uses MP-PCA
    - fMRI: Typically uses non-local means or wavelets
    - Anatomical: Typically uses non-local means
    
    Attributes:
        method: Denoising method to use
        patch_radius: Size of patch for local methods
        block_radius: Size of block for non-local methods
        
    Example:
        >>> # For dMRI
        >>> denoising = DenoisingStep(config, method='mppca')
        >>> denoised = denoising(dwi_file, output_dir)
        >>> 
        >>> # For fMRI
        >>> denoising = DenoisingStep(config, method='nlmeans')
        >>> denoised = denoising(bold_file, output_dir)
    """
    
    def __init__(
        self,
        config,
        method: Literal['mrtrix', 'ants', 'mppca', 'nlmeans', 'wavelets', 'gaussian'] = 'mrtrix',
        patch_radius: int = 2,
        block_radius: int = 5,
        logger: Optional[logging.Logger] = None,
        provenance = None
    ):
        """
        Initialize denoising step.
        
        Args:
            config: Pipeline configuration
            method: Denoising method to use
            patch_radius: Patch size for local methods (default: 2)
            block_radius: Block size for non-local methods (default: 5)
            logger: Optional logger instance
            provenance: Optional provenance tracker
        
        Raises:
            ProcessingError: If required dependencies are missing
        """
        super().__init__(config, logger, provenance)
        
        self.method = method
        self.patch_radius = patch_radius
        self.block_radius = block_radius
        
        # Check dependencies
        self._check_dependencies()
        
        self.logger.info(f"Initialized denoising with method: {method}")
    
    def _check_dependencies(self) -> None:
        """Check that required dependencies are available."""
        if self.method == 'mrtrix':
            # Assume MRtrix3 is installed and in PATH
            pass

        if self.method == 'ants':
            # Assume ANTs is installed and in PATH
            pass


        # if self.method == 'mppca' and not DIPY_AVAILABLE:
        #     raise ProcessingError(
        #         "DIPY not available. Install with: pip install dipy"
        #     )
        
        # if self.method == 'nlmeans' and not NLMEANS_AVAILABLE:
        #     raise ProcessingError(
        #         "DIPY nlmeans not available. Install with: pip install dipy"
        #     )
    
    def validate_inputs(
        self,
        input_image: Path,
        output_dir: Path,
        **kwargs
    ) -> None:
        """
        Validate denoising inputs.
        
        Args:
            input_image: Path to input NIfTI file
            output_dir: Output directory
            **kwargs: Additional arguments
        
        Raises:
            ValidationError: If inputs are invalid
        """
        # Check input file exists
        if not input_image.exists():
            raise ValidationError(f"Input image not found: {input_image}")
        
        # Check it's a valid NIfTI file
        try:
            img = nib.load(str(input_image))
            
            # Check dimensions
            if len(img.shape) < 3:
                raise ValidationError(
                    f"Input must be at least 3D, got shape {img.shape}"
                )
            
            # For MP-PCA, need 4D data
            if self.method == 'mppca' and len(img.shape) != 4:
                raise ValidationError(
                    f"MP-PCA requires 4D data, got shape {img.shape}"
                )
            
        except Exception as e:
            raise ValidationError(f"Invalid NIfTI file: {e}")
        
        self.logger.debug(f"Input validation passed for {input_image.name}")
    
    def run(self, input_img: Path, output_img: Path, mask: Optional[Path]=None, noise_map: Optional[Path]=None, **kwargs) -> Tuple[Path, Optional[Path]]:
        """
        Run denoising on input image.
        
        Args:
            input_img: Path to input NIfTI file
            output_img: Path to output NIfTI file for denoised image
            mask: Optional brain mask (speeds up processing)
            **kwargs: Method-specific parameters
        
        Returns:
            Path to denoised image
            Path to noise map: (Optional)
        
        Raises:
            ProcessingError: If denoising fails
        """
        output_dir = output_img.parent
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Run denoising based on method
        self.logger.info(f"Running {self.method} denoising...")
        
        try:
            if self.method == 'mrtrix':
                denoised, noise = mrtrix.dwidenoise(in_img=input_img,
                                                    out=output_img, 
                                                    mask=mask,
                                                    noise_map=noise_map,
                                                    nthreads=kwargs.get('nthreads', 2),
                                                    force=bool(kwargs.get('force', False)))
            elif self.method == 'ants':
                denoised, noise = ants.denoise_image(in_img=input_img,
                                                     out=output_img,
                                                     noise_model=kwargs.get('noise_model', 'Rician'),
                                                     mask=mask,
                                                     noise_map=noise_map,
                                                     nthreads=kwargs.get('nthreads', 2))
            elif self.method == 'mppca':
                denoised, noise = dipy.mppca(in_img=input_img, 
                                             out=output_img, 
                                             mask=mask,
                                             noise_map=noise_map, 
                                             **kwargs)
            elif self.method == 'nlmeans':
                denoised = dipy.nlmeans(in_img=input_img, 
                                        out=output_img, 
                                        mask=mask, 
                                        **kwargs)
                noise = None
            elif self.method == 'wavelets':
                denoised = self._run_wavelets(
                    nib.load(str(input_img)).get_fdata(),
                    mask=nib.load(str(mask)).get_fdata() if mask else None,
                    **kwargs
                )
                noise = None
            elif self.method == 'gaussian':
                denoised = self._run_gaussian(
                    nib.load(str(input_img)).get_fdata(),
                    mask=nib.load(str(mask)).get_fdata() if mask else None,
                    **kwargs
                )
                noise = None
            else:
                raise ValueError(f"Unknown denoising method: {self.method}")
            
        except Exception as e:
            raise ProcessingError(
                f"Denoising failed with method {self.method}",
                step_name="denoising",
                details=str(e)
            )
        
        # Save denoised image
        self.logger.info(f"Denoised image saved to: {output_file}")
        
        # Also save noise map if MP-PCA
        if noise_map is not None:
            self.logger.debug(f"Noise map saved to: {noise_map}")
        
        return denoised, noise
    
    def validate_outputs(self, result: Path) -> None:
        """
        Validate denoising outputs.
        
        Args:
            result: Path to output file
        
        Raises:
            ProcessingError: If output validation fails
        """
        if not result.exists():
            raise ProcessingError(f"Denoised image not created: {result}")
        
        # Check output is valid and has reasonable values
        try:
            img = nib.load(str(result))
            data = img.get_fdata()
            
            # Check for NaN or Inf
            if np.any(np.isnan(data)):
                raise ProcessingError("Denoised image contains NaN values")
            if np.any(np.isinf(data)):
                raise ProcessingError("Denoised image contains Inf values")
            
            # Check data range is reasonable (non-negative for MRI)
            if np.any(data < 0):
                self.logger.warning("Denoised image contains negative values")
            
            self.logger.debug(
                f"Output validation passed. "
                f"Data range: [{data.min():.2f}, {data.max():.2f}]"
            )
            
        except Exception as e:
            raise ProcessingError(f"Output validation failed: {e}")
    
    
    
    def _run_wavelets(
        self,
        data: np.ndarray,
        mask: Optional[np.ndarray] = None,
        **kwargs
    ) -> np.ndarray:
        """
        Run wavelet-based denoising.
        
        Uses soft thresholding in wavelet domain.
        
        Args:
            data: 3D or 4D array
            mask: Optional binary mask
            **kwargs: Additional parameters
        
        Returns:
            Denoised data
        """
        try:
            import pywt
        except ImportError:
            raise ProcessingError(
                "PyWavelets not available. Install with: pip install PyWavelets"
            )
        
        self.logger.debug("Running wavelet denoising")
        
        # Get wavelet type and threshold
        wavelet = kwargs.get('wavelet', 'db4')
        threshold_method = kwargs.get('threshold_method', 'BayesShrink')
        
        def denoise_3d(volume):
            """Denoise a 3D volume using wavelets."""
            # Perform 3D wavelet decomposition
            coeffs = pywt.wavedecn(volume, wavelet, level=3)
            
            # Threshold detail coefficients
            coeffs_thresh = [coeffs[0]]  # Keep approximation
            for detail in coeffs[1:]:
                detail_thresh = {}
                for key, value in detail.items():
                    if threshold_method == 'BayesShrink':
                        sigma = np.median(np.abs(value)) / 0.6745
                        thresh = sigma * np.sqrt(2 * np.log(value.size))
                    else:
                        thresh = kwargs.get('threshold', 1.0)
                    
                    detail_thresh[key] = pywt.threshold(
                        value, thresh, mode='soft'
                    )
                coeffs_thresh.append(detail_thresh)
            
            # Reconstruct
            denoised = pywt.waverecn(coeffs_thresh, wavelet)
            
            return denoised
        
        # Process data
        if len(data.shape) == 4:
            denoised_arr = np.zeros_like(data)
            for vol in range(data.shape[3]):
                denoised_arr[..., vol] = denoise_3d(data[..., vol])
        else:
            denoised_arr = denoise_3d(data)
        
        return denoised_arr
    
    def _run_gaussian(
        self,
        data: np.ndarray,
        mask: Optional[np.ndarray] = None,
        **kwargs
    ) -> np.ndarray:
        """
        Run simple Gaussian smoothing.
        
        Fallback method that doesn't require special dependencies.
        
        Args:
            data: 3D or 4D array
            mask: Optional binary mask
            **kwargs: Additional parameters
        
        Returns:
            Smoothed data
        """
        from scipy.ndimage import gaussian_filter
        
        sigma = kwargs.get('sigma', 1.0)
        self.logger.debug(f"Running Gaussian smoothing with sigma={sigma}")
        
        if len(data.shape) == 4:
            # Don't smooth in time dimension
            smoothed = np.zeros_like(data)
            for vol in range(data.shape[3]):
                smoothed[..., vol] = gaussian_filter(data[..., vol], sigma=sigma)
        else:
            smoothed = gaussian_filter(data, sigma=sigma)
        
        return smoothed
    
    def _log_provenance(
        self,
        input_image: Path,
        output_dir: Path,
        result: Path,
        mask: Optional[Path] = None,
        **kwargs
    ) -> None:
        """
        Log detailed provenance for denoising.
        
        Overrides base class method to add denoising-specific info.
        """
        if self.provenance:
            inputs = {'image': str(input_image)}
            if mask:
                inputs['mask'] = str(mask)
            
            parameters = {
                'method': self.method,
                'patch_radius': self.patch_radius,
                'block_radius': self.block_radius,
            }
            parameters.update(kwargs)
            
            self.provenance.log_step(
                step_name='denoising',
                inputs=inputs,
                outputs={'denoised_image': str(result)},
                parameters=parameters,
                duration=(self.end_time - self.start_time).total_seconds()
                if self.end_time and self.start_time else None
            )




# Convenience function for quick denoising
def denoise_image(input_image: Path, output_file: Path, method: str = 'mrtrix', mask: Optional[Path] = None, **kwargs) -> Path:
    """
    Convenience function for quick denoising without full pipeline setup.
    
    Args:
        input_image: Input image path
        output_image: Output image path
        method: Denoising method ('mrtrix', 'ants', 'mppca', 'nlmeans', etc.)
        mask: Optional mask path
        **kwargs: Method-specific parameters
    
    Returns:
        Path to denoised image
    
    Example:
        >>> from qmri_neuropipe.processing.common.denoising import denoise_image
        >>> 
        >>> denoised = denoise_image(
        ...     input_image=Path('dwi.nii.gz'),
        ...     output_file=Path('denoised.nii.gz'),
        ...     method='mppca'
        ... )
    """
    # Create minimal config
    from qmri_neuropipe.core import PipelineConfig
    
    config = PipelineConfig(
        bids_dir=Path('/tmp'),  # Dummy value
        output_dir=output_file.parent
    )
    
    # Run denoising
    denoiser = DenoisingStep(config, method=method)
    
    # Temporarily disable validation for standalone use
    denoiser.validate_inputs = lambda *args, **kwargs: None
    
    result = denoiser.run(
        input_image,
        output_file.parent,
        mask=mask,
        **kwargs
    )
    
    return result


# Module version and metadata
__version__ = '2.0.0'
__all__ = [
    'DenoisingStep',
    'denoise_image'
]
