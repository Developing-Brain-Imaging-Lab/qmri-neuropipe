from __future__ import annotations
from pathlib import Path
from typing import Optional, Tuple, Dict
import json
from ..bids import select_participants_sessions  # already in your skeleton

def load_dwi_from_bids(sub_dir: Path) -> Dict[Path, Path, Path, Path, Optional[Path], Optional[Path]]:
    """
    Very small helper: picks the first *_dwi.nii.gz and mates .bval/.bvec/.json.
    Extend as needed (multiple runs, AP/PA handling, etc.).
    """
    dwi = sorted((sub_dir / "dwi").glob("*_dwi.nii.gz"))[0]
    bval = Path(str(dwi).replace("_dwi.nii.gz", "_dwi.bval"))
    bvec = Path(str(dwi).replace("_dwi.nii.gz", "_dwi.bvec"))
    js   = Path(str(dwi).replace(".nii.gz", ".json")) if (Path(str(dwi).replace(".nii.gz", ".json"))).exists() else None

    acqp, index = build_acqp_index(js, dwi)

    return Dict(img=dwi, bval=bval, bvec=bvec, json=js, acqp=acqp, index=index)

def build_acqp_index(json_path: Path | None, dwi_path: Path) -> Tuple[Path | None, Path | None]:
    """
    Build minimal FSL acqp.txt and index.txt from BIDS JSON.
    This is a stub that writes a single PE dir/ro time line if JSON is present.
    Expand for multi-PE or TOPUP use.
    """
    if not json_path or not json_path.exists():
        return None, None

    meta = json.loads(json_path.read_text())
    pe = meta.get("PhaseEncodingDirection", "j")   # fallback
    trt = meta.get("TotalReadoutTime", 0.05)       # seconds

    acqp_dir = dwi_path.parent / "eddy"
    acqp_dir.mkdir(parents=True, exist_ok=True)
    acqp = acqp_dir / "acqp.txt"
    index = acqp_dir / "index.txt"

    # Map BIDS PE to FSL acqp (i/j/k with +/-). Using j as default example:
    # Columns are: dx dy dz readout_time
    line = {
        "i":  "1 0 0",
        "i-": "-1 0 0",
        "j":  "0 1 0",
        "j-": "0 -1 0",
        "k":  "0 0 1",
        "k-": "0 0 -1",
    }.get(pe, "0 1 0")

    acqp.write_text(f"{line} {trt:.6f}\n", encoding="utf-8")
    # Single line index for all volumes (adjust for multi-acqp scenarios)
    # Count volumes by reading bvals:
    nvols = len([x for x in Path(dwi_path.parent).glob("*_dwi.bval")][0].read_text().split())
    index.write_text(("1\n" * nvols), encoding="utf-8")

    return acqp, index